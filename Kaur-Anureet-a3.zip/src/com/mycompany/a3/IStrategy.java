package com.mycompany.a3;

public interface IStrategy {
	public int apply(NonPlayerCyborg nPC);
}
